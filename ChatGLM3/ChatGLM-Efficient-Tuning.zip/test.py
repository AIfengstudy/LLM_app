import subprocess

command = [
    'python',
    'src/web_demo.py',
    '--model_name_or_path',
    'D:/rkwork/ChatGLM3/chatglm3-models',
    '--finetuning_type',
    'lora',
    '--checkpoint_dir',
    'D:/rkwork/ChatGLM3/ChatGLM-Efficient-Tuning/muziAI'
]

subprocess.call(command)