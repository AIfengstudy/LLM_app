import subprocess

command = [
    'python',
    'src/export_model.py',
    '--model_name_or_path',
    '/home/rkwork/work_place/project/ChatGLM2-6B/models/chatglm2-6b',
    '--finetuning_type',
    'lora',
    '--checkpoint_dir',
    '/home/rkwork/work_place/project/ChatGLM2-6B/ChatGLM-Efficient-Tuning/cognition',
    '--output_dir',
    'muziAI'
]

subprocess.call(command)